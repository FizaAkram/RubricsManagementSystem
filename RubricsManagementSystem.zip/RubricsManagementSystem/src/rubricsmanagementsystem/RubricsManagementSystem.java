/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmanagementsystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author LAIBA AKRAM
 */
public class RubricsManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login l = new Login();
        l.setVisible(true);
//        ManageRubrics rubric = new ManageRubrics();
        ManageAssesments assesment = new ManageAssesments();
        ManageStudent student = new ManageStudent();
    }

    public void loadStudentData() {
        Boolean flag = true;
        try {
            FileReader file = new FileReader("StudentData.txt");
            BufferedReader br = new BufferedReader(file);
            String line = br.readLine();
        } catch (IOException e) {

        }
    }

    public void loadCLOData(ManageRubrics rubric) throws IOException {
        Boolean flag = true;
        try {
            FileReader file = new FileReader("CLOData.txt");
            BufferedReader br = new BufferedReader(file);
            String line;
            while ((line = br.readLine()) != null) {
                String[] strline = line.split(",");

                for (int i = 2; i < strline.length; i++) {
                    rubric = new ManageRubrics();
                    rubric.setRubric(strline[i]);
                    rubric.setCompMarks(Integer.parseInt(strline[i]));
                    rubric.getRubric();
                    rubric.getCompMarks();
                    rubric.rubricList.add(rubric.object);
                }
                rubric.object1 = new ManageRubrics();
                rubric.object1.rubricList.addAll(rubric.rubricList);
                rubric.setClo(strline[0]);
                rubric.getClo();
                rubric.setNumOfComp(Integer.parseInt(strline[1]));
                rubric.object1.getNumOfComp();
                rubric.cloList.add(rubric.object1);
                rubric.rubricList = new ArrayList<>();
            }
        } catch (IOException e) {

        }
    }

    public void loadAssesmentData(ManageAssesments assesment) {
        Boolean flag = true;
        try {
            FileReader file = new FileReader("AssesmentData.txt");
            BufferedReader br = new BufferedReader(file);
            String line;
            while ((line = br.readLine()) != null) {
                String[] strline = line.split(",");

                for (int i = 2; i < strline.length; i++) {
                    assesment.object = new ManageAssesments();

                    assesment.setMaxRubricLvl(Integer.parseInt(strline[i]));
                    assesment.object.getMaxRubricLvl();
                    assesment.object.getClo();
                    assesment.setQuestion(strline[i]);
                    assesment.object.getQuestion();
                    assesment.questionList.add(assesment.object);
                }
                assesment.object1 = new ManageAssesments();
                assesment.object1.questionList.addAll(assesment.questionList);
                assesment.setAssesment(Integer.parseInt(strline[0]));
                assesment.object1.getAssesment();
                assesment.setQuestionCount(Integer.parseInt(strline[1]));
                assesment.object1.getQuestionCount();
                assesment.assesList.add(assesment.object1);

            }
        } catch (IOException e) {

        }
    }

    public void writeStudentData() {

    }

    public void writeAssesmentData(ManageAssesments assesment) {
        try {
            FileWriter myFile = new FileWriter("AssesmentData.txt");
            for (int i = 0; i < assesment.assesList.size(); i++) {
                myFile.write(assesment.assesList.get(i).getAssesment() + ",");
                myFile.write(assesment.assesList.get(i).getQuestionCount() + ",");
                for (int j = 0; j < assesment.assesList.get(i).questionList.size(); j++) {
                    myFile.write(assesment.assesList.get(i).questionList.get(j).getClo() + ",");
                    myFile.write(assesment.assesList.get(i).questionList.get(j).getQuestion() + ",");
                    myFile.write(assesment.assesList.get(i).questionList.get(j).getMaxRubricLvl() + "\n");
                }
            }

            myFile.flush();
            myFile.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error occour in saving data");
        }
    }

    public void writeCLOData(ManageRubrics rubric) {
        try {
            FileWriter myFile = new FileWriter("CLOData.txt");
            for (int i = 0; i < rubric.cloList.size(); i++) {
                myFile.write(rubric.cloList.get(i).getClo() + ",");
                myFile.write(rubric.cloList.get(i).getNumOfComp() + ",");
                for (int j = 0; j < rubric.cloList.get(i).rubricList.size(); j++) {
                    myFile.write(rubric.cloList.get(i).rubricList.get(j).getRubric() + ",");
                    myFile.write(rubric.cloList.get(i).rubricList.get(j).getCompMarks() + "\n");
                }
            }

            myFile.flush();
            myFile.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error occour in saving data");
        }
    }

}
